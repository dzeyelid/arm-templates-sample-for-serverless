export default interface Task {
  userId: string
  title: string
  dueDate?: Date
}

